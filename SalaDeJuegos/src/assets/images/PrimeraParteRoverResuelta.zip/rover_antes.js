export class MarsRover {
    constructor(posicion, direccion) {
        this._posicion = posicion;
        this._direccion = direccion;
    }

    procesar(comandos) {
        Array.from(comandos).forEach(comando => {
            switch (comando) {
                case 'f':
                    switch (this._direccion) {
                        case "Norte":
                            this._posicion = this._posicion.sumarEnY(1);
                            break;

                        case "Este":
                            this._posicion = this._posicion.sumarEnX(1);
                            break;

                        case "Sur":
                            this._posicion = this._posicion.sumarEnY(-1);
                            break;

                        case "Oeste":
                            this._posicion = this._posicion.sumarEnX(-1);
                            break;
                    
                        default:
                            break;
                    }
                    break;

                case 'b':
                    switch (this._direccion) {
                        case "Norte":
                            this._posicion = this._posicion.sumarEnY(-1);
                            break;

                        case "Este":
                            this._posicion = this._posicion.sumarEnX(-1);
                            break;

                        case "Sur":
                            this._posicion = this._posicion.sumarEnY(1);
                            break;

                        case "Oeste":
                            this._posicion = this._posicion.sumarEnX(1);
                            break;
                    
                        default:
                            break;
                    }
                    break;

                case 'r':
                    switch (this._direccion) {
                        case "Norte":
                            this._direccion = "Este";
                            break;

                        case "Este":
                            this._direccion = "Sur";
                            break;
                    
                        case "Sur":
                            this._direccion = "Oeste";
                            break;

                        case "Oeste":
                            this._direccion = "Norte";
                            break;
                    
                        default:
                            break;
                    }
                    break;

                case 'l':
                    switch (this._direccion) {
                        case "Norte":
                            this._direccion = "Oeste";
                            break;

                        case "Este":
                            this._direccion = "Norte";
                            break;
                    
                        case "Sur":
                            this._direccion = "Este";
                            break;

                        case "Oeste":
                            this._direccion = "Sur";
                            break;
                    
                        default:
                            break;
                    }
                    break;
            
                default:
                    throw new Error("Comando inválido");
            }
        })
    }

    ubicacion() {
        return this._posicion;
    }
    
    direccion() {
        return this._direccion;
    }
}

export const norte = "Norte";
export const sur = "Sur";
export const este = "Este";
export const oeste = "Oeste";