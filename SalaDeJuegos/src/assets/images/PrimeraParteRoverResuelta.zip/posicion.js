class Posicion {
    constructor(x, y) {
        this._x = x;
        this._y = y;
    }

    sumarEnX(unaCantidad) {
        return new Posicion(this._x + unaCantidad, this._y);
    }

    sumarEnY(unaCantidad) {
        return new Posicion(this._x, this._y + unaCantidad);
    }
}

export function posicion(x, y) {
    return new Posicion(x, y);
}
