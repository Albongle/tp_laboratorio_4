export const norte = {
    rotarALaIzquierda(rover) {
        rover.mirarAl(oeste);
    },
    rotarALaDerecha(rover) {
        rover.mirarAl(este);
    },
    moverAdelante(rover) {
        rover.avanzarAlNorte();
    },
    moverAtras(rover) {
        rover.avanzarAlSur();
    }
};
export const sur = {
    rotarALaIzquierda(rover) {
        rover.mirarAl(este);
    },
    rotarALaDerecha(rover) {
        rover.mirarAl(oeste);
    },
    moverAdelante(rover) {
        rover.avanzarAlSur();
    },
    moverAtras(rover) {
        rover.avanzarAlNorte();
    }
};
export const este = {
    rotarALaIzquierda(rover) {
        rover.mirarAl(norte);
    },
    rotarALaDerecha(rover) {
        rover.mirarAl(sur);
    },
    moverAdelante(rover) {
        rover.avanzarAlEste();
    },
    moverAtras(rover) {
        rover.avanzarAlOeste();
    }
};
export const oeste = {
    rotarALaIzquierda(rover) {
        rover.mirarAl(sur);
    },
    rotarALaDerecha(rover) {
        rover.mirarAl(norte);
    },
    moverAdelante(rover) {
        rover.avanzarAlOeste();
    },
    moverAtras(rover) {
        rover.avanzarAlEste();
    }
};

export class MarsRover {
    constructor(posicion, direccion) {
        this._posicion = posicion;
        this._direccion = direccion;
        this._caracterAComando = new Map([
            ['f', () => this.moverseHaciaAdelante()],
            ['b', () => this.moverseHaciaAtras()],
            ['r', () => this.rotarALaDerecha()],
            ['l', () => this.rotarALaIzquierda()],
        ]);
    }

    procesar(cadenaDeComandos) {
        Array.from(cadenaDeComandos).forEach(caracterComando => this.ejecutarComando(caracterComando));
    }

    ejecutarComando(caracterComando) {
        if (!this._caracterAComando.has(caracterComando))
            throw new Error("Comando inválido");

        const comando = this._caracterAComando.get(caracterComando);
        comando();
    }

    rotarALaIzquierda() {
        this._direccion.rotarALaIzquierda(this);
    }

    mirarAl(unaDireccion) {
        this._direccion = unaDireccion;
    }

    rotarALaDerecha() {
        this._direccion.rotarALaDerecha(this);
    }

    moverseHaciaAtras() {
        this._direccion.moverAtras(this);
    }

    moverseHaciaAdelante() {
        this._direccion.moverAdelante(this);
    }

    avanzarAlOeste() {
        this._posicion = this._posicion.sumarEnX(-1);
    }

    avanzarAlSur() {
        this._posicion = this._posicion.sumarEnY(-1);
    }

    avanzarAlEste() {
        this._posicion = this._posicion.sumarEnX(1);
    }

    avanzarAlNorte() {
        this._posicion = this._posicion.sumarEnY(1);
    }

    ubicacion() {
        return this._posicion;
    }

    direccion() {
        return this._direccion;
    }
}
