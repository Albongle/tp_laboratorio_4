import { posicion } from './posicion';
import { MarsRover, norte, sur, este, oeste } from './rover';

test('el rover se mantiene inmovil si no recibe ningún comando', () => {
    const marsRover = new MarsRover(posicion(1, 2), norte);

    marsRover.procesar('');

    expect(marsRover.ubicacion()).toEqual(posicion(1, 2));
    expect(marsRover.direccion()).toEqual(norte);
});

test('cuando avanza mirando al norte, el rover suma 1 a su coordenada y, manteniendo su dirección', () => {
    const marsRover = new MarsRover(posicion(1, 2), norte);

    marsRover.procesar('f');

    expect(marsRover.ubicacion()).toEqual(posicion(1, 3));
    expect(marsRover.direccion()).toEqual(norte);
});

test('cuando retrocede mirando al norte, el rover resta 1 a su coordenada y, manteniendo su dirección', () => {
    const marsRover = new MarsRover(posicion(1, 2), norte);

    marsRover.procesar('b');

    expect(marsRover.ubicacion()).toEqual(posicion(1, 1));
    expect(marsRover.direccion()).toEqual(norte);
});

test('cuando gira a la derecha mirando al norte, el rover mira hacia el este, manteniendo su ubicación', () => {
    const marsRover = new MarsRover(posicion(1, 2), norte);

    marsRover.procesar('r');

    expect(marsRover.ubicacion()).toEqual(posicion(1, 2));
    expect(marsRover.direccion()).toEqual(este);
});

test('cuando gira a la izquierda mirando al norte, el rover mira hacia el oeste, manteniendo su ubicación', () => {
    const marsRover = new MarsRover(posicion(1, 2), norte);

    marsRover.procesar('l');

    expect(marsRover.ubicacion()).toEqual(posicion(1, 2));
    expect(marsRover.direccion()).toEqual(oeste);
});

test('el rover no procesa comandos inválidos', () => {
    const marsRover = new MarsRover(posicion(1, 2), norte);

    expect(() => {
        marsRover.procesar('x');
    }).toThrowError('Comando inválido')
    expect(marsRover.ubicacion()).toEqual(posicion(1, 2));
    expect(marsRover.direccion()).toEqual(norte);
});

test('el rover puede procesar una cadena con más de un comando', () => {
    const marsRover = new MarsRover(posicion(1, 2), norte);

    marsRover.procesar('ff');

    expect(marsRover.ubicacion()).toEqual(posicion(1, 4));
    expect(marsRover.direccion()).toEqual(norte);
});

test('cuando avanza mirando al este, el rover suma 1 a su coordenada x, manteniendo su dirección', () => {
    const marsRover = new MarsRover(posicion(1, 2), este);

    marsRover.procesar('f');

    expect(marsRover.ubicacion()).toEqual(posicion(2, 2));
    expect(marsRover.direccion()).toEqual(este);
});

test('cuando retrocede mirando al este, el rover resta 1 a su coordenada x, manteniendo su dirección', () => {
    const marsRover = new MarsRover(posicion(1, 2), este);

    marsRover.procesar('b');

    expect(marsRover.ubicacion()).toEqual(posicion(0, 2));
    expect(marsRover.direccion()).toEqual(este);
});

test('cuando gira a la derecha mirando al este, el rover mira hacia el sur, manteniendo su ubicación', () => {
    const marsRover = new MarsRover(posicion(1, 2), este);

    marsRover.procesar('r');

    expect(marsRover.ubicacion()).toEqual(posicion(1, 2));
    expect(marsRover.direccion()).toEqual(sur);
});

test('cuando gira a la izquierda mirando al este, el rover mira hacia el norte, manteniendo su ubicación', () => {
    const marsRover = new MarsRover(posicion(1, 2), este);

    marsRover.procesar('l');

    expect(marsRover.ubicacion()).toEqual(posicion(1, 2));
    expect(marsRover.direccion()).toEqual(norte);
});

test('el rover entiende los comandos mirando al sur', () => {
    const marsRover = new MarsRover(posicion(1, 2), sur);

    marsRover.procesar('ffbrllrr');

    expect(marsRover.ubicacion()).toEqual(posicion(1, 1));
    expect(marsRover.direccion()).toEqual(oeste);
});

test('el rover entiende los comandos mirando al oeste', () => {
    const marsRover = new MarsRover(posicion(1, 2), oeste);

    marsRover.procesar('ffbrllrr');

    expect(marsRover.ubicacion()).toEqual(posicion(0, 2));
    expect(marsRover.direccion()).toEqual(norte);
});

// Igualdad vs identidad
// - Identidad: cada objeto tiene su propia identidad.
//   Es lo que nos permite referirnos a _ese_ objeto en lugar de a otros.
//   En JS: uno === otro
// - Igualdad: un objeto es igual a sí mismo, pero además puede potencialmente ser
//   igual a otros objetos. Depende del dominio.
//   En algunos lenguajes, implementamos la igualdad por medio de mensajes, e.g.
//   equals(otro), ==(otro), ...

test('dos posiciones son iguales si sus coordenadas son iguales', () => {
    expect(posicion(1, 2)).toEqual(posicion(1, 2));
});

test('dos posiciones no son iguales si sus primeras coordenadas son diferentes', () => {
    expect(posicion(1, 2)).not.toEqual(posicion(2, 2));
});

test('dos posiciones no son iguales si sus segundas coordenadas son diferentes', () => {
    expect(posicion(1, 2)).not.toEqual(posicion(1, 1));
});
